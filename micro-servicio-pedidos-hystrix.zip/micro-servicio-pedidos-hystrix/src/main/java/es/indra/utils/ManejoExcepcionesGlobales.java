package es.indra.utils;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

@RestControllerAdvice
public class ManejoExcepcionesGlobales {

	// Todas las excepciones que ocurran en este microservicio se manejan aqui
	// Igual que try-catch podemos tener multiples catch
	// Aqui podemos tener varios metodos para capturar diferentes excepciones
	// A diferencia de los bloques catch que el orden es importante, aqui no

	// http://localhost:8002/crear/55567/cantidad/10
	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> errorNoExiste(RuntimeException ex) {
		System.out.println("ID no existe: " + ex.getMessage());
		return new ResponseEntity<String>("Ese ID no existe", HttpStatus.NOT_FOUND);
	}

	// http://localhost:8002/crear/hgvhgv/cantidad/10
	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseEntity<String> errorNoNumerico(MethodArgumentTypeMismatchException ex) {
		System.out.println("El ID debe ser numerico: " + ex.getMessage());
		return new ResponseEntity<String>("El ID debe ser numerico", HttpStatus.BAD_REQUEST);
	}

}
