package es.indra.persistence;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import es.indra.entities.Producto;

// Cuando Spring Boot detecta que estamos herando de xxxRepository crea automaticamente un bean de Spring
// Ejecuta import.sql
public interface ProductosDAO extends JpaRepository<Producto, Long>{
	
	// Podemos crear nuestros metodos personalizados utilizando palabras claves 
	// https://docs.spring.io/spring-data/jpa/reference/repositories/query-keywords-reference.html
		
	public List<Producto> findByDescripcion(String descripcion);
	
	public List<Producto> findByDescripcionOrderByPrecio(String descripcion);
	
	public List<Producto> findByDescripcionOrderByPrecioDesc(String descripcion);
	
	public List<Producto> findByPrecioBetween(double min, double max);
	
	@Query("select p from Producto p where p.precio < ?1")
	public List<Producto> miQuery(double precio);

}
