package es.indra.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.entities.Producto;
import es.indra.persistence.ProductosDAO;

/*
 * En Spring toda clase anotada con una de estas 4 anotaciones se reconoce como un bean de Spring:
 * 		@Repository; repositorios de datos (dao, conexion ldap, erp, ....etc)
 * 		@Service; clases de logica de negocio, business, ...etc
 * 		@Controller; Controladores de Spring MVC, Servicios REST
 * 		@Component; clase que no es ninguna de las anteriores
 * */

// objeto Java = bean de Spring
@Service
public class ProductosBSImpl implements IProductosBS{
	
	@Autowired   // (DI) Spring, por favor, inyecta un bean de tipo ProductosDAO que tengas en el contenedor
	private ProductosDAO dao;

	@Override
	public List<Producto> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Producto buscarProducto(Long id) {
		return dao.findById(id).orElse(new Producto());
	}

}
