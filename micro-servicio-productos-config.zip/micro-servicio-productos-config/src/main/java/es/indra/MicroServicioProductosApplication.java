package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class MicroServicioProductosApplication {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// (crear el contenedor, crear los beans, meter los beans en el contenedor, DI de beans)
		SpringApplication.run(MicroServicioProductosApplication.class, args);
	}

}
