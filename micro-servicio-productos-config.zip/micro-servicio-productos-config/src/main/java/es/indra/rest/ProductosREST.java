package es.indra.rest;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IProductosBS;
import es.indra.entities.Producto;

@RestController
public class ProductosREST {
	
	@Value("${server.port}")   // para inyectar valores (primitivos y String)
	private Integer port;
	
	@Autowired // para inyectar beans
	private IProductosBS bs;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return bs.consultarTodos()
				.stream()
				.map(prod -> {
					prod.setPort(port);
					return prod;
				})
				.collect(Collectors.toList());
	}
	
	// http://localhost:8001/buscar/3
	@GetMapping("/buscar/{codigo}")
	public Producto buscar(@PathVariable(name = "codigo") Long id) {
		Producto producto = bs.buscarProducto(id);
		producto.setPort(port);
		return producto;
	}

}
