package es.indra.rest;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IProductosBS;
import es.indra.entities.Producto;

@RestController
@RefreshScope
public class ProductosREST {
	
	@Value("${configuracion.modo}")
	private String perfil;
	
	@Value("${server.port}")   // para inyectar valores (primitivos y String)
	private Integer port;
	
	@Autowired // para inyectar beans
	private IProductosBS bs;
	
	// http://localhost:8011/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return bs.consultarTodos()
				.stream()
				.map(prod -> {
					prod.setPort(port);
					return prod;
				})
				.collect(Collectors.toList());
	}
	
	// http://localhost:8011/buscar/3
	@GetMapping("/buscar/{codigo}")
	public Producto buscar(@PathVariable(name = "codigo") Long id) {
		
		// Mostrar en que modo estamos
		System.out.println("****************** " + perfil);
		
		Producto producto = bs.buscarProducto(id);
		producto.setPort(port);
		return producto;
	}

}
