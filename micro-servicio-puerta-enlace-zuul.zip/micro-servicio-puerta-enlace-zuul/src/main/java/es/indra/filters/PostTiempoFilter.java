package es.indra.filters;

import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

@Component
public class PostTiempoFilter extends ZuulFilter{

	@Override
	public boolean shouldFilter() {
		return true;
	}

	@Override
	public Object run() throws ZuulException {
		// Tomar el tiempo final
		Long tiempoFinal = System.currentTimeMillis();
		
		// Recupero el tiempo de inicio como atributo de peticion
		RequestContext ctx = RequestContext.getCurrentContext();
		Long tiempoInicio =	(Long) ctx.getRequest().getAttribute("tiempoInicio");
		
		// Mostrar la diferencia de tiempos
		System.out.println("***************************************");
		System.out.println("Tiempo transcurrido: " + (tiempoFinal - tiempoInicio) + " mseg");
		System.out.println("***************************************");
		
		return null;
	}

	@Override
	public String filterType() {
		return "post";
	}

	@Override
	public int filterOrder() {
		return 1;
	}

}
