package es.indra.filters;

import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

@Component
public class PreTiempoFilter extends ZuulFilter{

	@Override
	public boolean shouldFilter() {
		// Activar o desactivar el filtro
		// Si retorna true -> se activa
		// si retorna false -> el filtro no esta activo y se ignora
		return true;
	}

	@Override
	public Object run() throws ZuulException {
		// Todo lo que quiero que ejecute el filtro
		
		// Tomar el tiempo de inicio
		Long tiempoInicio = System.currentTimeMillis();
		
		// Lo guardo como atributo de peticion
		RequestContext ctx = RequestContext.getCurrentContext();
		ctx.getRequest().setAttribute("tiempoInicio", tiempoInicio);
		
		return null;
	}

	@Override
	public String filterType() {
		// Hay que retornar uno de estos tres valores: "pre", "post", "route"
		//		pre: antes de enrutar la peticion
		//		post: despues de procesar la peticion
		//		route: en el momento de enrutar la peticion
		return "pre";
	}

	@Override
	public int filterOrder() {
		// Orden de ejecuccion del filtro en el caso de tener varios
		return 1;
	}

}
