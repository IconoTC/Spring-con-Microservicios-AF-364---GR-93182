package es.indra.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class JavaConfig {
	
	// El objeto Java retornado me lo convierte en un bean de Spring
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

}
