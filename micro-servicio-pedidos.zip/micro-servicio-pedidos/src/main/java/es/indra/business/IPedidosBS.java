package es.indra.business;

import es.indra.models.Pedido;

public interface IPedidosBS {
	
	Pedido crearPedido(Long id, int cantidad);

}
