package es.indra.filters;

import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Mono;

public class MedirTiempoFilter implements GlobalFilter, Ordered{

	@Override
	public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
		// ------- pre -------
		// Tomar el tiempo de inicio
		Long tiempoInicio = System.currentTimeMillis();
		
		// ------- post -------
		return chain.filter(exchange).then(Mono.fromRunnable(() -> {
			// Tomar el tiempo final
			Long tiempoFinal = System.currentTimeMillis();
			
			// Mostrar la diferencia de tiempos
			System.out.println("***************************************");
			System.out.println("Tiempo transcurrido: " + (tiempoFinal - tiempoInicio) + " mseg");
			System.out.println("***************************************");
		}));
	}

	@Override
	public int getOrder() {
		// Metodo de la interface Ordered
		// Establecer el orden en el caso de tener varios filtros
		return 1;
	}

}
