package es.indra.filters;

import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Mono;

//@Component
public class BloquearBuscarProductoFilter implements GlobalFilter, Ordered {

	@Override
	public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {

		// Coger el path de la peticion
		String path = exchange.getRequest().getURI().getPath();
		// System.out.println(path + "-----------------");

		// Bloquear la ruta para buscar un producto
		if (path.startsWith("/api/productos/buscar")) {
			exchange.getResponse().setStatusCode(HttpStatus.NOT_FOUND);

			byte[] bytes = "404 Not found".getBytes();

			DataBuffer buffer = exchange.getResponse().bufferFactory().wrap(bytes);

			return exchange.getResponse().writeWith(Mono.just(buffer));
		}

		return chain.filter(exchange);
	}

	@Override
	public int getOrder() {
		// Queremos que este filtro se ejecute antes que MedirTiempoFilter
		return -1;
	}

}
