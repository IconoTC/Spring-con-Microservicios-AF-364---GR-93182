<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
	<head>
	    <title>Mostrar mensajes</title>
	</head>
	<body>
	    <h1>Mensaje:</h1>
	    
		<%= request.getAttribute("msg") %>
		
	</body>
</html>