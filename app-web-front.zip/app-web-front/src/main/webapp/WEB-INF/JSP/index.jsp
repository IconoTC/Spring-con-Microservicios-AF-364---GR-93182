<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://www.springframework.org/tags" prefix="spring" %>
<!DOCTYPE html>
<html>
	<head>
	    <title>Pagina principal</title>
	</head>
	<body>
	    <h1><spring:message code="inicio.titulo" /></h1>
		
		<div style="float:right;">
			<a href="inicio?locale=es">
				<img src="imagenes/banderas/spain.png" width="40" />
			</a>
			<a href="inicio?locale=en">
				<img src="imagenes/banderas/inglaterra.png" width="40" />
			</a>
			<a href="inicio?locale=fr">
				<img src="imagenes/banderas/francia.png" width="40" />
			</a>
			<a href="inicio?locale=de">
				<img src="imagenes/banderas/alemania.png" width="40" />
			</a>
		</div>
	    
		<a href="todos"><spring:message code="inicio.todos" /></a> <br/>
		
		<a href="buscar"><spring:message code="inicio.buscar" /></a> <br/>
		
		<a href="registro"><spring:message code="inicio.registro" /></a> <br/>
	</body>
</html>