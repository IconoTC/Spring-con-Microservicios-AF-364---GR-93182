<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="es.indra.models.Producto" %>
<!DOCTYPE html>
<html>
	<head>
	    <title>Catalogo</title>
	</head>
	<body>
	    <h1>Detalle del producto encontrado</h1>
	    
			
		<jsp:useBean id="encontrado" class="es.indra.models.Producto" scope="request"></jsp:useBean>
		
		
		<ul>
			<li>ID: <jsp:getProperty property="ID" name="encontrado" /> </li>
			<li>DESCRIPCION: <jsp:getProperty property="descripcion" name="encontrado" /> </li>
			<li>PRECIO: <jsp:getProperty property="precio" name="encontrado" /> </li>
		</ul>
			
		
	</body>
</html>