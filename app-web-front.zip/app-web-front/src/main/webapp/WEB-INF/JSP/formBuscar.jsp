<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://www.springframework.org/tags/form" prefix="sf" %>
<!DOCTYPE html>
<html>
	<head>
	    <title>Formulario buscar</title>
	</head>
	<body>
	    <h1>Buscar un producto</h1>
	    
		<sf:form action="buscar" method="POST" modelAttribute="prod">
			
			<sf:label path="ID">Introduce ID:</sf:label>
			<sf:input path="ID"/> <br/>
			
			<input type="submit" value="Buscar producto" />
		
		</sf:form>
		
	</body>
</html>