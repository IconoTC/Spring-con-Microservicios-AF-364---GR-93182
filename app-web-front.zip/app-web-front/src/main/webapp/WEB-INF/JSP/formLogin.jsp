<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
	<head>
	    <title>Formulario Login</title>
	</head>
	<body>
	    <h1>Login de usuario</h1>
	    
		<form action="login" method="POST">
			
			<label>User:</label>
			<input type="text" name="user"/> <br/>
			
			<label>Password:</label>
			<input type="password" name="pw"/> <br/>
			
			<input type="submit" value="Enviar" />
		
		</form>
		
	</body>
</html>