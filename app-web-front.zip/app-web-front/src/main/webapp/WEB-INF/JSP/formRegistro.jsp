<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://www.springframework.org/tags/form" prefix="sf" %>
<!DOCTYPE html>
<html>
	<head>
	    <title>Formulario registro</title>
	</head>
	<body>
	    <h1>Introduce tus datos para registrarte</h1>
	    
		<sf:form action="registro" method="POST" modelAttribute="cliente">
			
			<sf:label path="nombre">Nombre:</sf:label>
			<sf:input path="nombre"/> 
			<sf:errors path="nombre" /> <br/>
			
			<sf:label path="apellido">Apellido:</sf:label>
			<sf:input path="apellido"/> 
			<sf:errors path="apellido" /><br/>
			
			<sf:label path="email">Email:</sf:label>
			<sf:input path="email"/> 
			<sf:errors path="email" /><br/>
			
			<sf:label path="edad">Edad:</sf:label>
			<sf:input path="edad"/> 
			<sf:errors path="edad" /><br/>
			
			<input type="submit" value="Registrarme" />
		
		</sf:form>
		
	</body>
</html>