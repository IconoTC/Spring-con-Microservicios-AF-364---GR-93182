package es.indra.entities;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data  // getter, setter, equals, hascode y toString
@NoArgsConstructor   // constructor por defecto
@AllArgsConstructor  // constructor completo
public class Cliente {
	
	@NotNull(message = "El Nombre es obligatorio")
	@Size(min=3, max=20, message = "Debe tener entre 3 y 20 caracteres")
	private String nombre;
	
	@NotNull(message = "El apellido es obligatorio")
	@Size(min=3, max=20, message = "Debe tener entre 3 y 20 caracteres")
	private String apellido;
	
	@Email(message = "El email no es valido")
	private String email;
	
	@Digits(integer = 3, fraction = 0, message = "Debe tener 3 digitos maximo")
	@DecimalMin(value = "18", message = "No eres mayor de edad")
	@DecimalMax(value = "100", message = "Edad maxima 100 años")
	private int edad;

}


// crear un enlace de registro en index
// Crear RegistroController (mostrarFormulario,  procesarFormulario)
// formRegistro.jsp