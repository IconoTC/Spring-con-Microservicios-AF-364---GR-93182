package es.indra.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import es.indra.business.IGestionBS;
import es.indra.models.Producto;

@Controller
@RequestMapping("/buscar")
public class BuscarController {

    private final TodosController todosController;
	
	@Autowired
	private IGestionBS bs;

    BuscarController(TodosController todosController) {
        this.todosController = todosController;
    }

	@RequestMapping(method = RequestMethod.GET)
	public String mostrarFormulario(Model model) {
		// Crear una instancia de Producto que enviamos al formulario para
		// que se rellenen los datos
		model.addAttribute("prod", new Producto());
		return "formBuscar";
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public String procesarFormulario(@ModelAttribute("prod") Producto producto, Model model) {
		Producto encontrado = bs.buscar(producto.getID());
		
		if (encontrado.getDescripcion() != null) {
			// si encuentra el producto, lo guarda en model y se muestra en mostrarProducto.jsp
			model.addAttribute("encontrado", encontrado);
			return "mostrarProducto";
		} else {
			// si no lo encuentra crear un mensaje: "Ese producto no existe en nuestro catalogo"
			//   y se muestra en mostrarMensaje.jsp
			model.addAttribute("msg", "Ese producto no existe en nuestro catalogo");
			return "mostrarMensaje";
		}
	}
}
