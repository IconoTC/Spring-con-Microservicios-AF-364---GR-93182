package es.indra.controllers;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import es.indra.entities.Cliente;

@Controller
@RequestMapping("/registro")
public class RegistroController {
	
	@GetMapping
	public String mostrarFormulario(Model model){
		model.addAttribute("cliente", new Cliente());
		return "formRegistro";
	}
	
	@PostMapping
	public String procesarFormulario(@Valid @ModelAttribute("cliente") Cliente cliente, 
			BindingResult resultado, Model model) {
		if (resultado.hasErrors()) {
			return "formRegistro";
		} else {
			model.addAttribute("msg", "Proceso de registro completado");
			return "mostrarMensaje";
		}
	}

}
