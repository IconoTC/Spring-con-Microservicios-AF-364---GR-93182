package es.indra.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping({"/", "/home", "/inicio"})
public class InicioController {

	@RequestMapping(method = RequestMethod.GET, value = "")
	public String inicio() {
		// retorna el nombre de la vista (pagina JSP)
		return "index";
	}
}
