package es.indra.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data  // incluye @Getter @Setter @RequiredArgsConstructor @ToString @EqualsAndHashCode.
@NoArgsConstructor  // Genera el constructor sin argumentos
@AllArgsConstructor  // Constructor con todos los argumentos
public class Producto {
	
	private Long ID;
	
	private String descripcion;
	
	private double precio;
	
	private Integer port;

}
