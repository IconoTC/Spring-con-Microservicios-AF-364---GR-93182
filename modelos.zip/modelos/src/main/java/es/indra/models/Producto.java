package es.indra.models;

public class Producto {
	
	private Long ID;
	
	private String descripcion;
	
	private double precio;

}
