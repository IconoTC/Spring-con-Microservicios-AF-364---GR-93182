package es.indra.models;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Carrito {
	
	private String id;  // lo genera MongoDB al persistir el documento
	
	private String usuario;
	
	private List<Pedido> contenido = new ArrayList<>();
	
	private double importe;

	// Necesito un constructor completo sin id
	public Carrito(String usuario, List<Pedido> contenido, double importe) {
		super();
		this.usuario = usuario;
		this.contenido = contenido;
		this.importe = importe;
	}
	
}
