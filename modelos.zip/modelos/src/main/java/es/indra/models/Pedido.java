package es.indra.models;

public class Pedido {
	
	private Producto producto;
	
	private int cantidad;

}
