package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

//import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import es.indra.business.IPedidosBS;
import es.indra.models.Pedido;
import es.indra.models.Producto;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
//  @RequestMapping("/api")
public class PedidosREST {
	
	@Autowired  // No puedo especificar que bean de los 2 inyectar
	//@Qualifier(value = "pedidosBSImplFeign")
	@Qualifier(value = "bsFeign")
	private IPedidosBS bs;
	
	
	/*
	 * El problema de Hystrix es que si tengo 20 operaciones en este servicio REST
	 * necesito 20 metodos alternativos, entonces es mas rentable
	 * crear un manejo de excepciones globales
	 * */
	
	// http://localhost:8002/crear/2/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	//@HystrixCommand(fallbackMethod = "manejarError")
	@CircuitBreaker(fallbackMethod = "manejarError", name = "pedidos")
	public Pedido crearPedido(@PathVariable Long id, @PathVariable int cantidad) {
		return bs.crearPedido(id, cantidad);
	}
	
	// Crear un metodo alternativo para manejar la excepcion
	// Este metodo debe tener los mismos argumentos + Throwable
	// El metodo debe retornar el mismo tipo
	public Pedido manejarError(Long id, int cantidad, Throwable ex) {
		// Procesar la excepcion recibida
		System.out.println(ex.getMessage() + "**************************");
		System.out.println(ex.getClass() + "**************************");
		
		Producto producto = new Producto(id, "Producto vacio", 100, null);
		return new Pedido(producto, cantidad);
	}

}
